package com.louis.mango.admin.service;

import com.louis.mango.admin.model.SysLog;
import com.louis.mango.core.service.CurdService;

/**
 * 操作日志
 * @author Louis
 * @date Jan 13, 2019
 */
public interface SysLogService extends CurdService<SysLog> {

}
