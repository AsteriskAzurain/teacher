package com.ishang.demo.admin.service;

import com.ishang.demo.admin.model.SysLog;
import com.ishang.demo.core.service.CurdService;

/**
 * 操作日志
 *create by zhayao 2020年3月30日
 */
public interface SysLogService extends CurdService<SysLog> {

}
