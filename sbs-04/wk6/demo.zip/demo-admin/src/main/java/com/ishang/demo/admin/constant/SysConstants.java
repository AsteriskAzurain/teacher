package com.ishang.demo.admin.constant;

 
/**
 * 
 * 常量管理
 *
 * create by zhayao 2020年3月30日
 */
public interface SysConstants {

	/**
	 * 系统管理员用户名
	 */
	String ADMIN = "admin";
	
}
