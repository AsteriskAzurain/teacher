package com.ishang.service;

public interface StudentService {
	
	public boolean checkUser(String usercode);

}
