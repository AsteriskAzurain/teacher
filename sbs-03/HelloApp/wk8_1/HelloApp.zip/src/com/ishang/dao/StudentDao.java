package com.ishang.dao;

import com.ishang.entity.StudentsInfo;

/**
 * 
 * @Description: （）
 *
 * @author zhayao  
 *
 * @date: 2019年10月15日 上午9:22:04
 */
public interface StudentDao extends BaseDao<StudentsInfo> { 
 

}
