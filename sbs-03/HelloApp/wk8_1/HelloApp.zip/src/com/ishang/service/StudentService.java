package com.ishang.service;

import com.ishang.entity.StudentsInfo;

public interface StudentService extends BaseService<StudentsInfo> {

	
}
