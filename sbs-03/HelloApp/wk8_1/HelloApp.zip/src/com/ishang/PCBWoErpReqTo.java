package com.ishang;

public class PCBWoErpReqTo {	 
	private  String  crafts_property; 
	private  long  id;
	private  int  ismain; 
	private  String  location_code;
	private  String  main_materiel_code;
	private  String  materiel_code;
	private  String  materiel_desc;
	private  String  materiel_name;
	private  String  memo;
	private  double  mtrl_dosage;
	private  double  req_qty; 
	private  int  sequence;
	private  String  wo;  
	private String ebs_udpate_date;
	public String getCrafts_property() {
		return crafts_property;
	}
	public void setCrafts_property(String crafts_property) {
		this.crafts_property = crafts_property;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getIsmain() {
		return ismain;
	}
	public void setIsmain(int ismain) {
		this.ismain = ismain;
	}
	public String getLocation_code() {
		return location_code;
	}
	public void setLocation_code(String location_code) {
		this.location_code = location_code;
	}
	public String getMain_materiel_code() {
		return main_materiel_code;
	}
	public void setMain_materiel_code(String main_materiel_code) {
		this.main_materiel_code = main_materiel_code;
	}
	public String getMateriel_code() {
		return materiel_code;
	}
	public void setMateriel_code(String materiel_code) {
		this.materiel_code = materiel_code;
	}
	public String getMateriel_desc() {
		return materiel_desc;
	}
	public void setMateriel_desc(String materiel_desc) {
		this.materiel_desc = materiel_desc;
	}
	public String getMateriel_name() {
		return materiel_name;
	}
	public void setMateriel_name(String materiel_name) {
		this.materiel_name = materiel_name;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public double getMtrl_dosage() {
		return mtrl_dosage;
	}
	public void setMtrl_dosage(double mtrl_dosage) {
		this.mtrl_dosage = mtrl_dosage;
	}
	public double getReq_qty() {
		return req_qty;
	}
	public void setReq_qty(double req_qty) {
		this.req_qty = req_qty;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public String getWo() {
		return wo;
	}
	public void setWo(String wo) {
		this.wo = wo;
	}
	public String getEbs_udpate_date() {
		return ebs_udpate_date;
	}
	public void setEbs_udpate_date(String ebs_udpate_date) {
		this.ebs_udpate_date = ebs_udpate_date;
	}
	
}
