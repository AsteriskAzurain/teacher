package com.huatec.edu.mobileshop.dao;

import java.util.List;

import com.huatec.edu.mobileshop.entity.GoodsImg;

public interface GoodsImgDao {
	public int save(GoodsImg goodsImg);
	public int deleteById(int img_id);
	public List<GoodsImg> findAll();
	public GoodsImg findById(int img_id);
	public int dynamicUpdate(GoodsImg goodsImg);
}
