package com.huatec.edu.mobileshop.entity;

import java.io.Serializable;
import java.sql.Timestamp;
//商品图片引用
public class GoodsImg implements Serializable {
	private Integer img_id;//图片编号
	private Integer goods_id;//商品编号
	private String thumbnail;//缩略图
	private String big;//大图
	private String small;//小图
	private String original;//原图
	private Integer isdefault;//是否为主图，0：是主图，1：不是主图
	private Timestamp creatime;//创建时间
	private Timestamp modifytime;//修改时间
	
	public Integer getImg_id() {
		return img_id;
	}
	public void setImg_id(Integer img_id) {
		this.img_id = img_id;
	}
	public Integer getGoods_id() {
		return goods_id;
	}
	public void setGoods_id(Integer goods_id) {
		this.goods_id = goods_id;
	}
	public String getThumbnail() {
		return thumbnail;
	}
	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}
	public String getBig() {
		return big;
	}
	public void setBig(String big) {
		this.big = big;
	}
	public String getSmall() {
		return small;
	}
	public void setSmall(String small) {
		this.small = small;
	}
	public String getOriginal() {
		return original;
	}
	public void setOriginal(String original) {
		this.original = original;
	}
	public Integer getIsdefault() {
		return isdefault;
	}
	public void setIsdefault(Integer isdefault) {
		this.isdefault = isdefault;
	}
	public Timestamp getCreatime() {
		return creatime;
	}
	public void setCreatime(Timestamp creatime) {
		this.creatime = creatime;
	}
	public Timestamp getModifytime() {
		return modifytime;
	}
	public void setModifytime(Timestamp modifytime) {
		this.modifytime = modifytime;
	}
	
	public String toString() {
		return "GoodsImg [img_id=" + img_id + ", goods_id=" + goods_id + ", thumbnail=" + thumbnail + ", big=" + big
				+ ", small=" + small + ", original=" + original + ", isdefault=" + isdefault + ", creatime=" + creatime
				+ ", modifytime=" + modifytime + "]";
	}
	
	
}
